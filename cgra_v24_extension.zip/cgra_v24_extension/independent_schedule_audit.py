"""Independently replay frozen calendars and solve small cases by forward state DP."""
from pathlib import Path
import hashlib,json,time
ROOT=Path(__file__).resolve().parent
out=ROOT/'schedule_independent_audit_01';out.mkdir(exist_ok=False)
start=time.perf_counter();cpu=time.process_time()
b=next(ROOT.glob('scheduling_benchmark_*'))
cases=json.loads((b/'output_02/instances.json').read_text());rows=json.loads((b/'output_02/rows.json').read_text());report=json.loads((b/'output_02/result.json').read_text())
def verify(case,order):
 if order is None:return None
 assert len(order)==sum(case['lengths'])
 seen=[0]*case['n'];value=-1
 for t,i in enumerate(order):
  assert isinstance(i,int) and 0<=i<case['n'];seen[i]+=1;assert seen[i]<=case['lengths'][i]
  if seen[i]==case['lengths'][i]:
   assert t>=case['guards'][i];value=max(value,t+case['tails'][i])
 assert seen==case['lengths'];return value

def optimum(case):
 lengths=case['lengths'];states={(0,)*case['n']:-1}
 for slot in range(sum(lengths)):
  children={}
  for state,value in states.items():
   for i,n in enumerate(state):
    if n>=lengths[i]:continue
    completing=n+1==lengths[i]
    if completing and slot<case['guards'][i]:continue
    child=list(state);child[i]+=1;child=tuple(child)
    v=max(value,slot+case['tails'][i]) if completing else value
    children[child]=min(children.get(child,v),v)
  states=children
 return states.get(tuple(lengths))
oracles={c['id']:optimum(c) for c in cases if c['n']==4};verified=0
for row in rows:
 c=cases[row['id']];assert verify(c,row['order'])==row['value'];verified+=1
 if row['method']=='exact_guarded' and c['n']==4:assert oracles[c['id']]==row['value']
for group in report['summary']:
 matching=[r for r in rows if r['method']==group['method'] and r['family']==group['family']]
 assert len(matching)==group['total'];assert sum(r['value'] is not None for r in matching)==group['feasible']
 exact={r['id']:r['value'] for r in rows if r['family']==group['family'] and r['method']=='exact_guarded'}
 assert sum(r['value'] is not None and r['value']==exact[r['id']] for r in matching)==group['equal_exact']
controls=0
for order in [[0],[0,0,0,0],[-1,0],[0,99]]:
 try:verify({'n':2,'lengths':[1,1],'guards':[1,0],'tails':[0,0]},order)
 except AssertionError:controls+=1
assert controls==4
result={'returned_calendar_replays':verified,'independent_forward_dp_cases':len(oracles),'optimum_mismatches':0,'summary_groups_recomputed':len(report['summary']),'negative_controls_rejected':controls,'instances_sha256':hashlib.sha256((b/'output_02/instances.json').read_bytes()).hexdigest(),'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'mapper_calls':0,'native_calls':0,'EPFL_reads':0}
(out/'REPORT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
