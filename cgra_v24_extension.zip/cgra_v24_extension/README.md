# V24 scheduling and vector-diagram extension

This archive supplements `cgra_artifact_source.zip` in the same repository. It adds 1,200 frozen synthetic packet calendars and four scheduling policies, with all 4,800 outcomes, infeasible cases and costs. These are static calendar experiments. They are separate from native application and public-mapper measurements in the base archive. EPFL was not read.

Using Python 3.11 or later, from this extracted directory, run the independent forward-DP and schedule replay with `python3 -I -B independent_schedule_audit.py`. It rechecks 4,800 outcomes, all 400 four-chain optima, 16 summaries and four rejecting controls. The audit creates a new output directory and refuses to overwrite it. Use a fresh extraction to repeat.

Re-execute the frozen comparison with `python3 -I -B scheduling_benchmark_a7f8c2f54b9348d181d5b8929edc83eb/run.py --output NEW_OUTPUT_DIRECTORY`. The instance SHA-256 must equal `6456452cedc21d7c025ad190025b49853dd22de4e397c40025d6ab0e34a693a9`. Outcome and objective fields reproduce. Timings vary by machine. Runtime totals exclude prior input generation. The recorded initial import failure had zero method calls.

Create the two editable vector drawings with `python3 -B figures/draw_v24.py NEW_FIGURE_DIRECTORY`. This command needs Matplotlib and uses explicit coordinates, vector paths and editable SVG text. The four active tiles are a conceptual view of the array. The base archive supplies the other two measured-result plots and data.

`source_manifest.json` hashes every member except itself. The original results and independent audit are preserved. No result from this archive establishes full-flow public-mapper or application speedups.
