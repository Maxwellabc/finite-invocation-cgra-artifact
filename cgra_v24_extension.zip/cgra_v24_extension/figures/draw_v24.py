"""Hand-positioned vector diagrams. Preserve measured plots from V23.1."""
from pathlib import Path
import os,sys
os.environ['SOURCE_DATE_EPOCH']='1793923200'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,FancyArrowPatch
ROOT=Path(sys.argv[1]);ROOT.mkdir(exist_ok=False)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'pdf.fonttype':42,'svg.fonttype':'none','svg.hashsalt':'cgra-v24'})
blue='#346287';orange='#b86b32';green='#39745c';gray='#58616a'
def rect(ax,x,y,w,h,text,color=blue,fs=8):
 ax.add_patch(Rectangle((x,y),w,h,facecolor='white',edgecolor=color,lw=.85));ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=fs,color=color)
def arrow(ax,a,b,color=gray):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=9,lw=.85,color=color))
def save(fig,name):
 for ext in ['pdf','svg']:fig.savefig(ROOT/(name+'.'+ext),bbox_inches='tight',pad_inches=.035,metadata={'Creator':'Vector drawing script'} if ext=='pdf' else {'Creator':'Vector drawing script','Date':None})
 plt.close(fig)
fig,ax=plt.subplots(figsize=(3.45,2.25));ax.set(xlim=(0,10),ylim=(0,6.6));ax.axis('off')
rect(ax,.1,4.8,2.15,.85,'Host CPU');rect(ax,.1,3.2,2.15,.9,'Memory',green)
ax.text(6.8,6.45,'Active tiles in a 4 × 4 array',ha='center',fontsize=7.2)
for x,y,t in [(4,4.7,'A\nload'),(7.2,4.7,'B\nadd'),(4,2.95,'C\nstore'),(7.2,2.95,'D\nreturn')]:rect(ax,x,y,2.2,1.1,t,fs=8)
arrow(ax,(2.3,5.22),(3.9,5.22),orange);ax.text(3.1,5.65,'setup /\nlaunch',ha='center',fontsize=7,color=orange)
arrow(ax,(6.25,5.25),(7.1,5.25),blue);ax.plot([8.3,8.3,5.1],[4.65,4.35,4.35],color=blue,lw=.85);arrow(ax,(5.1,4.35),(5.1,4.1),blue)
arrow(ax,(6.3,3.45),(7.15,3.45),blue);arrow(ax,(3.95,3.45),(2.3,3.65),green)
ax.text(6.75,4.5,'data',ha='center',fontsize=7,color=blue)
arrow(ax,(9.48,3.5),(9.48,2.25),green);ax.plot([9.48,2.7,2.7],[2.25,2.25,4.85],color=green,lw=.85);arrow(ax,(2.7,4.85),(2.3,4.95),green)
ax.text(5.1,2.4,'designated return → host acceptance',ha='center',fontsize=7,color=green)
ax.plot([.35,9.65],[.9,.9],color=gray,lw=.8);arrow(ax,(9.3,.9),(9.8,.9))
for x,t,col in [(1.05,'setup',orange),(3.35,'launch',orange),(6.5,'last store $W$',green),(8.8,'return $H$',green)]:
 ax.plot([x,x],[.78,1.05],color=col,lw=.8);ax.text(x,1.15,t,ha='center',fontsize=7,color=col)
ax.text(5,.27,'minimize $H$     store visible first ($W < H$)',ha='center',fontsize=8)
save(fig,'problem_contract')
fig,ax=plt.subplots(figsize=(3.45,2.1));ax.set(xlim=(0,10),ylim=(0,6.1));ax.axis('off')
ax.text(5,5.75,'Two tiles, two packets each',ha='center',fontsize=8.5)
ax.text(5,5.1,'A needs launch ≥ 2, tail 3; B tail 0',ha='center',fontsize=7.7)
for y,label,entries,score in [(3.55,'Block',['B setup','B start','A setup','A start'],'$E=6$'),(1.95,'Interleave',['A setup','B setup','A start','B start'],'$E=5$')]:
 ax.text(.05,y+.35,label,ha='left',fontsize=7.5)
 for i,t in enumerate(entries):
  x=2.4+1.55*i;rect(ax,x,y,1.45,.75,t,blue if t[0]=='A' else orange,6.4);ax.text(x+.72,y-.28,str(i),ha='center',fontsize=7)
 ax.text(9.45,y+.35,score,ha='center',fontsize=8)
ax.text(5,4.35,'host packet slots',ha='center',fontsize=7,color=gray)
for x,t in [(.1,'Build windows'),(3.55,'Select head'),(7,'Check & run')]:rect(ax,x,.15,2.85,.7,t,green,7)
arrow(ax,(3,.5),(3.5,.5));arrow(ax,(6.45,.5),(6.95,.5))
save(fig,'method_flow')
