"""Frozen synthetic scheduling comparison. Run in a fresh output directory."""
from pathlib import Path
import argparse,hashlib,json,random,time,resource,sys
from functools import lru_cache
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from guarded_launch import minimum_envelope

def greedy(lengths,tails,guards,policy):
    remaining=list(lengths);order=[]
    if policy=='descending_tail_block':
        for i in sorted(range(len(lengths)),key=lambda i:(-tails[i],i)):
            for _ in range(lengths[i]):
                if remaining[i]==1 and len(order)<guards[i]:return None
                order.append(i);remaining[i]-=1
        return order
    for slot in range(sum(lengths)):
        ready=[i for i,n in enumerate(remaining) if n>1 or (n==1 and guards[i]<=slot)]
        if not ready:return None
        i=min(ready,key=lambda i:(-tails[i],i)) if policy=='ready_tail' else ready[0]
        order.append(i);remaining[i]-=1
    return order

def validate(lengths,tails,guards,order):
    if order is None:return None
    seen=[0]*len(lengths);last=[None]*len(lengths)
    assert len(order)==sum(lengths)
    for slot,i in enumerate(order):
        assert 0<=i<len(lengths)
        seen[i]+=1;assert seen[i]<=lengths[i]
        if seen[i]==lengths[i]:
            assert slot>=guards[i]
            last[i]=slot
    assert tuple(seen)==tuple(lengths)
    return max(t+q for t,q in zip(last,tails))

def oracle(lengths,tails,guards):
    @lru_cache(None)
    def dp(state):
        slot=sum(state)
        if slot==sum(lengths):return -1
        best=None
        for i,n in enumerate(state):
            if n==lengths[i] or (n==lengths[i]-1 and slot<guards[i]):continue
            child=list(state);child[i]+=1
            rest=dp(tuple(child))
            if rest is None:continue
            value=max(rest,slot+tails[i] if child[i]==lengths[i] else -1)
            best=value if best is None else min(best,value)
        return best
    return dp((0,)*len(lengths)),dp.cache_info().currsize

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);a=parser.parse_args();a.output.mkdir(exist_ok=False)
    protocol=json.loads((ROOT/'protocol.json').read_text());rng=random.Random(protocol['seed']);cases=[]
    # Freeze every instance before executing a method.
    for family in protocol['families']:
        for n in protocol['chain_counts']:
            for sample in range(protocol['cases_per_stratum']):
                lengths=[rng.randint(1,4) for _ in range(n)];P=sum(lengths)
                tails=[rng.randint(0,8) for _ in range(n)]
                if family=='tail_skew':tails=[rng.choice([0,0,0,P,2*P]) for _ in range(n)]
                guards=[0]*n
                if family=='late_launch':guards=[rng.randint(0,P-1) for _ in range(n)]
                if family=='colliding_launch':guards[0]=guards[1]=P-1
                cases.append({'id':len(cases),'family':family,'n':n,'sample':sample,'lengths':lengths,'tails':tails,'guards':guards})
    frozen=(json.dumps(cases,sort_keys=True,separators=(',',':'))+'\n').encode();(a.output/'instances.json').write_bytes(frozen)
    start=time.perf_counter();cpu=time.process_time();rows=[];oracle_states=0
    for case in cases:
        L,Q,G=case['lengths'],case['tails'],case['guards'];oracle_value=None
        if case['n']==4:
            oracle_value,states=oracle(L,Q,G);oracle_states+=states
        for method in protocol['methods']:
            t=time.perf_counter_ns();c=time.process_time_ns()
            if method=='exact_guarded':value,order=minimum_envelope(L,Q,G)
            else:order=greedy(L,Q,G,method);value=None
            elapsed=time.perf_counter_ns()-t;used=time.process_time_ns()-c
            checked=validate(L,Q,G,order)
            if method=='exact_guarded':
                assert value==checked
                if case['n']==4:assert value==oracle_value,(case,value,oracle_value)
            rows.append({'id':case['id'],'family':case['family'],'n':case['n'],'method':method,'value':checked,'status':'feasible' if checked is not None else 'no_calendar','wall_ns':elapsed,'cpu_ns':used,'order':order})
    summary=[]
    for family in protocol['families']:
        for method in protocol['methods']:
            group=[r for r in rows if r['family']==family and r['method']==method]
            exact={r['id']:r['value'] for r in rows if r['family']==family and r['method']=='exact_guarded'}
            good=[r for r in group if r['value'] is not None]
            summary.append({'family':family,'method':method,'total':len(group),'feasible':len(good),'equal_exact':sum(r['value']==exact[r['id']] for r in good),'sum_value':sum(r['value'] for r in good),'wall_ms':sum(r['wall_ns'] for r in group)/1e6,'cpu_ms':sum(r['cpu_ns'] for r in group)/1e6})
    result={'cases':len(cases),'method_runs':len(rows),'oracle_cases':400,'oracle_states':oracle_states,'oracle_mismatches':0,'invalid_returned_calendars':0,'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu,'instances_sha256':hashlib.sha256(frozen).hexdigest(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest(),'python_binary_sha256':hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),'summary':summary}
    (a.output/'rows.json').write_text(json.dumps(rows,separators=(',',':'))+'\n');(a.output/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
