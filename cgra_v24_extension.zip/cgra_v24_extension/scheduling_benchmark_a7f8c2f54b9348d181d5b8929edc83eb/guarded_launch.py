"""Exact static envelope for fixed chains with release constraints on LAUNCH only."""
from heapq import heappop, heappush

def schedule(lengths, tails, guards, start, envelope, *, witness=False):
    """Return feasibility or a chain-index sequence (None means infeasible).

    start, guards and the envelope are absolute zero-based packet indices.
    Every chain has positive length, with LAUNCH last. No idle slot is allowed.
    """
    stop = start + sum(lengths)
    groups = []
    for chain, (length, tail, guard) in enumerate(zip(lengths, tails, guards)):
        deadline = min(stop - 1, envelope - tail)
        if length > 1:
            groups.append((start, deadline - 1, chain, length - 1))
        groups.append((max(start, guard), deadline, chain, 1))
    groups.sort()
    if any(release > deadline for release, deadline, _, _ in groups):
        return None if witness else False
    ready = []
    event = 0
    slot = start
    order = [] if witness else None
    while slot < stop:
        while event < len(groups) and groups[event][0] <= slot:
            _, deadline, chain, amount = groups[event]
            heappush(ready, (deadline, chain, amount))
            event += 1
        if not ready:
            return None if witness else False
        deadline, chain, amount = heappop(ready)
        next_event = groups[event][0] if event < len(groups) else stop
        batch = min(amount, next_event - slot)
        if slot + batch - 1 > deadline:
            return None if witness else False
        if witness:
            order.extend([chain] * batch)
        if batch < amount:
            heappush(ready, (deadline, chain, amount - batch))
        slot += batch
    return order if witness else True

def minimum_envelope(lengths, tails, guards, start=0):
    """Return the minimum feasible static envelope and a witness, if one exists."""
    lower = start + sum(lengths) - 1 + min(tails)
    upper = start + sum(lengths) - 1 + max(tails)
    if not schedule(lengths, tails, guards, start, upper):
        return None, None
    while lower < upper:
        mid = (lower + upper) // 2
        if schedule(lengths, tails, guards, start, mid):
            upper = mid
        else:
            lower = mid + 1
    return lower, schedule(lengths, tails, guards, start, lower, witness=True)
