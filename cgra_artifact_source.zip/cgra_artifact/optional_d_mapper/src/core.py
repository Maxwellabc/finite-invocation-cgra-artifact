#!/usr/bin/env python3
"""Common-domain adaptation, routing, register allocation, checking, and lowering."""

from collections import defaultdict, deque
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import math


WIDTH = 4
HEIGHT = 4
TILES = 16
BANKS = 4
ENTRIES = 8
SLOTS = BANKS * ENTRIES
KINDS = {"AND": (10, 2), "NOT": (11, 1)}
BOUNDARY_KINDS = {"PI", "PO", "CONST"}
PORTS = {"NORTH": "SOUTH", "SOUTH": "NORTH", "EAST": "WEST", "WEST": "EAST"}


def canonical_bytes(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n").encode("ascii")


def sha256_bytes(value):
    return hashlib.sha256(value).hexdigest()


def sha256_path(path):
    return sha256_bytes(Path(path).read_bytes())


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def tile_xy(tile):
    return tile % WIDTH, tile // WIDTH


def strict_relation(source, destination):
    if not (0 <= source < TILES and 0 <= destination < TILES):
        return None
    if source == destination:
        return "LOCAL_RF"
    sx, sy = tile_xy(source)
    dx, dy = tile_xy(destination)
    return "MESH" if abs(sx - dx) + abs(sy - dy) == 1 else None


def mesh_port(source, destination):
    relation = strict_relation(source, destination)
    if relation == "LOCAL_RF":
        return "LOCAL_RF", "LOCAL_RF", f"local:{source}"
    if relation != "MESH":
        raise ValueError("not a strict-mesh hop")
    sx, sy = tile_xy(source)
    dx, dy = tile_xy(destination)
    if dx == sx + 1:
        output = "EAST"
    elif dx == sx - 1:
        output = "WEST"
    elif dy == sy + 1:
        output = "NORTH"
    else:
        output = "SOUTH"
    return output, PORTS[output], f"mesh:{source}:{output}:{destination}"


def neighbor_tiles(tile):
    values = [candidate for candidate in range(TILES) if strict_relation(tile, candidate) == "MESH"]
    return sorted(values)


def graph_parts(graph):
    nodes = {row["id"]: row for row in graph["nodes"]}
    compute = {key: row for key, row in nodes.items() if not row.get("zero_resource", False)}
    boundary = {key: row for key, row in nodes.items() if row.get("zero_resource", False)}
    return nodes, compute, boundary


def validate_graph(graph):
    failures = []
    nodes, compute, boundary = graph_parts(graph)
    if graph.get("schema_version") != 1:
        failures.append("schema_version")
    if len(nodes) != len(graph.get("nodes", [])):
        failures.append("duplicate_node")
    if set(row.get("kind") for row in compute.values()) - set(KINDS):
        failures.append("compute_kind")
    if set(row.get("kind") for row in boundary.values()) - BOUNDARY_KINDS:
        failures.append("boundary_kind")
    seen_edges = set()
    operands = defaultdict(set)
    for edge in graph.get("edges", []):
        if edge.get("id") in seen_edges:
            failures.append("duplicate_edge")
        seen_edges.add(edge.get("id"))
        if edge.get("src") not in nodes or edge.get("dst") not in nodes:
            failures.append("dangling_edge")
            continue
        if edge.get("distance") != 0 or edge.get("predicate") is not True:
            failures.append("edge_contract")
        dst = edge["dst"]
        if dst in compute:
            operand = edge.get("operand")
            if operand in operands[dst]:
                failures.append("duplicate_operand")
            operands[dst].add(operand)
    for node_id, row in compute.items():
        expected = set(range(KINDS[row["kind"]][1]))
        if operands[node_id] != expected:
            failures.append(f"operand_set:{node_id}")
        if row.get("opcode") != KINDS[row["kind"]][0]:
            failures.append(f"opcode:{node_id}")
        if row.get("latency") != 1 or row.get("resource") != "LogicRTL":
            failures.append(f"compute_contract:{node_id}")
        if row.get("predicate") is not True:
            failures.append(f"predicate:{node_id}")
    return sorted(set(failures))


def topological_metrics(graph):
    failures = validate_graph(graph)
    if failures:
        raise ValueError(f"invalid graph: {failures}")
    nodes, compute, _ = graph_parts(graph)
    successors = {node: [] for node in compute}
    predecessors = {node: [] for node in compute}
    fanout = dict.fromkeys(compute, 0)
    indegree = dict.fromkeys(compute, 0)
    for edge in graph["edges"]:
        if edge["src"] in compute:
            fanout[edge["src"]] += 1
        if edge["src"] in compute and edge["dst"] in compute:
            successors[edge["src"]].append(edge["dst"])
            predecessors[edge["dst"]].append(edge["src"])
            indegree[edge["dst"]] += 1
    queue = deque(sorted(node for node, degree in indegree.items() if degree == 0))
    order = []
    asap = dict.fromkeys(compute, 0)
    while queue:
        node = queue.popleft()
        order.append(node)
        for target in sorted(successors[node]):
            asap[target] = max(asap[target], asap[node] + 1)
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
                queue = deque(sorted(queue))
    if len(order) != len(compute):
        raise ValueError("compute graph is not acyclic")
    remaining = dict.fromkeys(compute, 1)
    for node in reversed(order):
        if successors[node]:
            remaining[node] = 1 + max(remaining[target] for target in successors[node])
    span = max((asap[node] + 1 for node in compute), default=0)
    alap = {node: span - remaining[node] for node in compute}
    mobility = {node: alap[node] - asap[node] for node in compute}
    return {
        "order": order,
        "asap": asap,
        "alap": alap,
        "mobility": mobility,
        "remaining_critical_path": remaining,
        "fanout": fanout,
        "critical_path_span": span,
        "successors": successors,
        "predecessors": predecessors,
    }


def build_arm_ir(graph, graph_file_sha256, arm, ii, source_fingerprint):
    if arm not in {"A_current", "B_upstream"}:
        raise ValueError("SAT adapter arm must be A_current or B_upstream")
    if ii < 1:
        raise ValueError("II must be positive")
    metrics = topological_metrics(graph)
    _, compute, boundary = graph_parts(graph)
    ordered_nodes = sorted(compute)
    integer_ids = {node: index for index, node in enumerate(ordered_nodes)}
    compute_edges = []
    boundary_edges = []
    for edge in graph["edges"]:
        row = deepcopy(edge)
        if edge["src"] in compute and edge["dst"] in compute:
            row["src_int"] = integer_ids[edge["src"]]
            row["dst_int"] = integer_ids[edge["dst"]]
            compute_edges.append(row)
        else:
            boundary_edges.append(row)
    adjacency = {str(tile): neighbor_tiles(tile) for tile in range(TILES)}
    return {
        "schema_version": 1,
        "arm": arm,
        "circuit": graph["circuit"],
        "graph_file_sha256": graph_file_sha256,
        "canonical_graph_sha256": graph["canonical_graph_sha256"],
        "hardware_contract_sha256": graph["hardware_contract_sha256"],
        "source_fingerprint": source_fingerprint,
        "II": ii,
        "seed_policy": {"python_hash_seed": 0, "z3_smt_random_seed": 0, "z3_sat_random_seed": 0},
        "integer_ids": integer_ids,
        "reverse_ids": {str(value): key for key, value in integer_ids.items()},
        "compute_nodes": [deepcopy(compute[node]) | {"integer_id": integer_ids[node]} for node in ordered_nodes],
        "compute_edges": sorted(compute_edges, key=lambda row: row["id"]),
        "boundary_nodes": [deepcopy(boundary[node]) for node in sorted(boundary)],
        "boundary_edges": sorted(boundary_edges, key=lambda row: row["id"]),
        "strict_mesh_adjacency": adjacency,
        "local_relation": "LOCAL_RF is allowed only for same-tile holding and is not a network edge",
        "mobility": {
            node: {
                "asap": metrics["asap"][node],
                "alap": metrics["alap"][node],
                "mobility": metrics["mobility"][node],
                "remaining_critical_path": metrics["remaining_critical_path"][node],
                "fanout": metrics["fanout"][node],
            }
            for node in ordered_nodes
        },
        "constraints": {
            "C1": "exactly one (absolute_time,tile) literal per compute node",
            "C2": "at most one compute node per tile and modulo phase",
            "C3": "each compute dependency uses same-tile LOCAL_RF or one strict cardinal hop; longer delays hold on source tile",
            "register_feedback": arm == "A_current",
            "B_forbids_project_register_cuts": arm == "B_upstream",
        },
    }


def route_step(cycle, source, destination):
    output, input_port, channel = mesh_port(source, destination)
    return {
        "cycle": int(cycle),
        "tile_id": int(source),
        "input_port": input_port,
        "output_port": output,
        "channel_id": channel,
    }


def step_destination(step):
    if step["output_port"] == "LOCAL_RF":
        return step["tile_id"]
    text = step["channel_id"].split(":")
    if len(text) != 4 or text[0] != "mesh":
        raise ValueError("malformed channel_id")
    return int(text[3])


def register_segments(edge_record):
    segments = []
    current = None
    for step in edge_record["route_steps"]:
        if step["output_port"] != "LOCAL_RF":
            if current is not None:
                segments.append(current)
                current = None
            continue
        tile = step["tile_id"]
        cycle = step["cycle"]
        if current is None or current["tile_id"] != tile or current["end"] != cycle:
            if current is not None:
                segments.append(current)
            current = {"tile_id": tile, "start": cycle, "end": cycle + 1}
        else:
            current["end"] = cycle + 1
    if current is not None:
        segments.append(current)
    return segments


def periodic_version_items(edge_records, ii):
    items = []
    for edge in sorted(edge_records, key=lambda row: row["edge_id"]):
        for segment_index, segment in enumerate(register_segments(edge)):
            lifetime = segment["end"] - segment["start"]
            versions = max(1, math.ceil(lifetime / ii))
            for lane in range(versions):
                occupancy = sorted({(segment["start"] + offset) % ii for offset in range(lifetime)})
                window_start = segment["start"] + lane * ii
                window_end = segment["end"] + lane * ii
                item_id = f"{edge['edge_id']}@{segment['tile_id']}:{segment_index}:v{lane}"
                items.append({
                    "item_id": item_id,
                    "value_id": edge["edge_id"],
                    "edge_id": edge["edge_id"],
                    "version": lane,
                    "tile_id": segment["tile_id"],
                    "write_time": window_start,
                    "read_times": [window_end],
                    "last_writer_node": edge["src"],
                    "lifetime_cycles": lifetime,
                    "period_cycles": versions * ii,
                    "occupancy_window_start": window_start,
                    "occupancy_window_end": window_end,
                    "occupancy_phases": occupancy,
                })
    return items


def periodic_items_conflict(left, right):
    if left["tile_id"] != right["tile_id"]:
        return False
    difference = left["occupancy_window_start"] - right["occupancy_window_start"]
    modulus = math.gcd(left["period_cycles"], right["period_cycles"])
    minimum = -left["lifetime_cycles"] + 1
    maximum = right["lifetime_cycles"] - 1
    first = minimum + ((difference - minimum) % modulus)
    return first <= maximum


def allocate_registers(edge_records, ii):
    items = periodic_version_items(edge_records, ii)
    by_id = {row["item_id"]: row for row in items}
    colors = {}
    by_tile = defaultdict(list)
    for item_id, row in by_id.items():
        by_tile[row["tile_id"]].append(item_id)

    for tile in sorted(by_tile):
        ids = sorted(by_tile[tile])
        conflicts = {item_id: set() for item_id in ids}
        for index, left_id in enumerate(ids):
            for right_id in ids[index + 1:]:
                if periodic_items_conflict(by_id[left_id], by_id[right_id]):
                    conflicts[left_id].add(right_id)
                    conflicts[right_id].add(left_id)
        clique = []
        for item_id in sorted(ids, key=lambda value: (-len(conflicts[value]), value)):
            if all(other in conflicts[item_id] for other in clique):
                clique.append(item_id)
                if len(clique) > SLOTS:
                    return None
        tile_colors = {}

        def choose_vertex():
            remaining = [item_id for item_id in ids if item_id not in tile_colors]
            if not remaining:
                return None

            def key(item_id):
                saturation = len({tile_colors[other] for other in conflicts[item_id] if other in tile_colors})
                return (-saturation, -len(conflicts[item_id]), item_id)

            return sorted(remaining, key=key)[0]

        def search():
            vertex = choose_vertex()
            if vertex is None:
                return True
            forbidden = {tile_colors[other] for other in conflicts[vertex] if other in tile_colors}
            used = sorted(set(tile_colors.values()))
            candidate_colors = used + ([len(used)] if len(used) < SLOTS else [])
            for color in candidate_colors:
                if color in forbidden:
                    continue
                tile_colors[vertex] = color
                if search():
                    return True
                del tile_colors[vertex]
            return False

        if not search():
            return None
        colors.update(tile_colors)
    records = []
    for item_id in sorted(by_id):
        row = deepcopy(by_id[item_id])
        color = colors[item_id]
        row["bank"] = color // ENTRIES
        row["index"] = color % ENTRIES
        records.append(row)
    return records


def boundary_records(graph, node_records):
    placement = {row["node_id"]: row for row in node_records}
    nodes, compute, boundary = graph_parts(graph)
    records = []
    for edge in sorted(graph["edges"], key=lambda row: row["id"]):
        if edge["src"] in boundary and edge["dst"] in compute:
            target = placement[edge["dst"]]
            records.append({
                "boundary_node_id": edge["src"], "kind": nodes[edge["src"]]["kind"], "edge_id": edge["id"],
                "operand": edge["operand"], "tile_id": target["tile_id"], "port": f"FU_IN_{edge['operand']}",
                "cycle": target["absolute_time"], "direction": "ingress",
                "value": nodes[edge["src"]].get("value") if nodes[edge["src"]]["kind"] == "CONST" else None,
            })
        elif edge["src"] in compute and edge["dst"] in boundary:
            source = placement[edge["src"]]
            records.append({
                "boundary_node_id": edge["dst"], "kind": nodes[edge["dst"]]["kind"], "edge_id": edge["id"],
                "operand": edge["operand"], "tile_id": source["tile_id"], "port": "FU_OUT",
                "cycle": source["absolute_time"] + 1, "direction": "egress", "value": None,
            })
        elif edge["src"] in boundary and edge["dst"] in boundary:
            raise ValueError("boundary-to-boundary edge is unsupported")
    return records


def candidate_shell(graph, graph_file_sha256, arm, ii, node_records, edge_records, source_fingerprint):
    registers = allocate_registers(edge_records, ii)
    return {
        "schema_version": 1,
        "arm": arm,
        "circuit": graph["circuit"],
        "graph_file_sha256": graph_file_sha256,
        "canonical_graph_sha256": graph["canonical_graph_sha256"],
        "hardware_contract_sha256": graph["hardware_contract_sha256"],
        "source_fingerprint": source_fingerprint,
        "II": ii,
        "seed_policy": {"python_hash_seed": 0, "z3_smt_random_seed": 0, "z3_sat_random_seed": 0},
        "node_records": sorted(node_records, key=lambda row: row["node_id"]),
        "edge_records": sorted(edge_records, key=lambda row: row["edge_id"]),
        "register_records": [] if registers is None else registers,
        "boundary_records": boundary_records(graph, node_records),
        "predicate": "always_true",
    }


def check_candidate(graph, candidate):
    failures = []
    checks = 0

    def check(code, condition, detail=None):
        nonlocal checks
        checks += 1
        if not condition:
            failures.append({"code": code, "detail": detail})

    graph_failures = validate_graph(graph)
    check("graph", not graph_failures, graph_failures)
    check("schema_version", candidate.get("schema_version") == 1)
    check("circuit", candidate.get("circuit") == graph.get("circuit"))
    check("arm", candidate.get("arm") in {"A_current", "B_upstream", "D_deterministic"})
    check("canonical_graph_sha256", candidate.get("canonical_graph_sha256") == graph.get("canonical_graph_sha256"))
    check("hardware_contract_sha256", candidate.get("hardware_contract_sha256") == graph.get("hardware_contract_sha256"))
    check("source_fingerprint", isinstance(candidate.get("source_fingerprint"), str) and len(candidate["source_fingerprint"]) == 64 and all(character in "0123456789abcdef" for character in candidate["source_fingerprint"]))
    check("seed_policy", candidate.get("seed_policy") == {"python_hash_seed": 0, "z3_smt_random_seed": 0, "z3_sat_random_seed": 0})
    ii = candidate.get("II")
    check("ii", type(ii) is int and ii > 0, ii)
    if type(ii) is not int or ii < 1:
        return {"status": "fail", "checks": checks, "failures": failures}
    nodes, compute, boundary = graph_parts(graph)
    records = candidate.get("node_records", [])
    by_node = {row.get("node_id"): row for row in records}
    check("node_set", set(by_node) == set(compute), sorted(set(compute) - set(by_node)))
    check("node_unique", len(by_node) == len(records))
    occupancy = {}
    for node_id, row in by_node.items():
        if node_id not in compute:
            continue
        phase = row.get("phase")
        absolute = row.get("absolute_time")
        tile = row.get("tile_id")
        check(f"node:{node_id}:tile", type(tile) is int and 0 <= tile < TILES, tile)
        check(f"node:{node_id}:time", type(absolute) is int and absolute >= 0, absolute)
        check(f"node:{node_id}:phase", type(absolute) is int and type(phase) is int and phase == absolute % ii, [phase, absolute])
        check(f"node:{node_id}:original", row.get("original_node_id") == node_id)
        check(f"node:{node_id}:iteration", type(absolute) is int and row.get("iteration_index") == absolute // ii)
        check(f"node:{node_id}:kind", row.get("kind") == compute[node_id]["kind"])
        check(f"node:{node_id}:opcode", row.get("opcode") == compute[node_id]["opcode"])
        check(f"node:{node_id}:latency", row.get("latency") == compute[node_id]["latency"])
        if type(tile) is int and type(phase) is int:
            key = (phase, tile)
            check(f"node:{node_id}:occupancy", key not in occupancy, [key, occupancy.get(key)])
            occupancy[key] = node_id
    expected_edges = {row["id"]: row for row in graph["edges"] if row["src"] in compute and row["dst"] in compute}
    edge_records = candidate.get("edge_records", [])
    by_edge = {row.get("edge_id"): row for row in edge_records}
    check("edge_set", set(by_edge) == set(expected_edges), sorted(set(expected_edges) - set(by_edge)))
    check("edge_unique", len(by_edge) == len(edge_records))
    channels = {}
    inputs = {}
    output_counts = defaultdict(int)
    route_hops = 0
    port_conflicts = 0
    predicate_violations = 0
    for edge_id, saved in by_edge.items():
        if edge_id not in expected_edges:
            continue
        edge = expected_edges[edge_id]
        source = by_node.get(edge["src"])
        target = by_node.get(edge["dst"])
        if source is None or target is None:
            continue
        identity_ok = all(saved.get(key) == edge[key] for key in ["src", "dst", "operand", "distance", "predicate"])
        if saved.get("predicate") is not edge.get("predicate"):
            predicate_violations += 1
        check(f"edge:{edge_id}:identity", identity_ok)
        launch = source["absolute_time"] + 1
        arrival = target["absolute_time"]
        check(f"edge:{edge_id}:launch", saved.get("launch_time") == launch)
        check(f"edge:{edge_id}:arrival", saved.get("arrival_time") == arrival and arrival >= launch, [saved.get("arrival_time"), arrival])
        steps = saved.get("route_steps", [])
        check(f"edge:{edge_id}:step_count", len(steps) == arrival - launch, [len(steps), arrival - launch])
        tile = source["tile_id"]
        for offset, step in enumerate(steps):
            cycle = launch + offset
            check(f"edge:{edge_id}:step:{offset}:cycle", step.get("cycle") == cycle)
            check(f"edge:{edge_id}:step:{offset}:tile", step.get("tile_id") == tile)
            try:
                next_tile = step_destination(step)
                relation = strict_relation(tile, next_tile)
            except Exception:
                next_tile = None
                relation = None
            check(f"edge:{edge_id}:step:{offset}:relation", relation in {"MESH", "LOCAL_RF"})
            if relation is not None:
                expected_output, expected_input, expected_channel = mesh_port(tile, next_tile)
                check(f"edge:{edge_id}:step:{offset}:ports", (step.get("output_port"), step.get("input_port"), step.get("channel_id")) == (expected_output, expected_input, expected_channel))
                phase = cycle % ii
                if relation == "MESH":
                    route_hops += 1
                    channel_key = (phase, expected_channel)
                    input_key = (phase, next_tile, expected_input)
                    if channel_key in channels:
                        port_conflicts += 1
                    if input_key in inputs:
                        port_conflicts += 1
                    check(f"edge:{edge_id}:step:{offset}:channel_capacity", channel_key not in channels, channels.get(channel_key))
                    check(f"edge:{edge_id}:step:{offset}:input_capacity", input_key not in inputs, inputs.get(input_key))
                    channels[channel_key] = edge_id
                    inputs[input_key] = edge_id
                    output_counts[(phase, tile)] += 1
                    if output_counts[(phase, tile)] > 2:
                        port_conflicts += 1
                    check(f"edge:{edge_id}:step:{offset}:output_lanes", output_counts[(phase, tile)] <= 2, output_counts[(phase, tile)])
            if next_tile is not None:
                tile = next_tile
        check(f"edge:{edge_id}:destination_tile", tile == target["tile_id"], [tile, target["tile_id"]])
        route_kind = "DIRECT" if not steps else ("LOCAL_RF" if all(step["output_port"] == "LOCAL_RF" for step in steps) else "MESH")
        check(f"edge:{edge_id}:route_kind", saved.get("route_kind") == route_kind, [saved.get("route_kind"), route_kind])
    expected_registers = allocate_registers(edge_records, ii)
    register_violations = 0
    if expected_registers is None:
        register_violations += 1
        check("register_allocation", False, "capacity")
    else:
        actual_registers = candidate.get("register_records", [])
        if canonical_bytes(actual_registers) != canonical_bytes(expected_registers):
            register_violations += 1
        check("register_records", canonical_bytes(actual_registers) == canonical_bytes(expected_registers))
    expected_boundary = boundary_records(graph, records) if set(by_node) == set(compute) else []
    actual_boundary = candidate.get("boundary_records", [])
    boundary_violations = 0 if canonical_bytes(actual_boundary) == canonical_bytes(expected_boundary) else 1
    check("boundary_records", boundary_violations == 0)
    check("predicate", candidate.get("predicate") == "always_true")
    if candidate.get("predicate") != "always_true":
        predicate_violations += 1
    fifo_violations = 0
    return {
        "status": "pass" if not failures else "fail",
        "checks": checks,
        "failures": failures,
        "route_hops": route_hops,
        "port_conflicts": port_conflicts,
        "register_violations": register_violations,
        "fifo_violations": fifo_violations,
        "predicate_violations": predicate_violations,
        "boundary_violations": boundary_violations,
        "failure_records": failures,
    }


def lower_configuration(candidate, checker_summary):
    if checker_summary.get("status") != "pass":
        return {
            "status": "illegal", "records": None, "bytes": None, "compute_records": None,
            "route_records": None, "register_records": None, "constant_records": None,
            "launch_records": None, "prologue_records": None, "required_successful_handshakes": None,
        }, None
    records = []
    counts = defaultdict(int)
    for node in sorted(candidate["node_records"], key=lambda row: (row["tile_id"], row["phase"], row["node_id"])):
        records.append({
            "record_class": "compute_control", "node_id": node["node_id"], "tile_id": node["tile_id"],
            "opcode": node["opcode"], "latency": node["latency"], "phase": node["phase"],
            "absolute_time": node["absolute_time"],
        })
        counts["compute"] += 1
    for edge in sorted(candidate["edge_records"], key=lambda row: row["edge_id"]):
        for step in edge["route_steps"]:
            if step["output_port"] == "LOCAL_RF":
                continue
            destination = step_destination(step)
            records.append({
                "record_class": "route_control", "edge_id": edge["edge_id"], "operand": edge["operand"],
                "source_tile": step["tile_id"], "destination_tile": destination,
                "input_port": step["input_port"], "output_port": step["output_port"],
                "channel_id": step["channel_id"], "phase": step["cycle"] % candidate["II"],
                "cycle": step["cycle"],
            })
            counts["route"] += 1
    for register in sorted(candidate["register_records"], key=lambda row: row["item_id"]):
        records.append({
            "record_class": "register_control", "item_id": register["item_id"],
            "edge_id": register["edge_id"], "version": register["version"], "tile_id": register["tile_id"],
            "bank": register["bank"], "index": register["index"], "write_time": register["write_time"],
            "read_times": register["read_times"], "last_writer_node": register["last_writer_node"],
            "lifetime_cycles": register["lifetime_cycles"], "period_cycles": register["period_cycles"],
            "occupancy_window_start": register["occupancy_window_start"],
            "occupancy_window_end": register["occupancy_window_end"],
            "occupancy_phases": register["occupancy_phases"],
        })
        counts["register"] += 1
    for boundary in sorted(candidate["boundary_records"], key=lambda row: row["edge_id"]):
        if boundary["kind"] != "CONST":
            continue
        records.append({
            "record_class": "constant", "boundary_node_id": boundary["boundary_node_id"],
            "edge_id": boundary["edge_id"], "operand": boundary["operand"], "value": boundary["value"],
            "tile_id": boundary["tile_id"], "port": boundary["port"],
            "phase": boundary["cycle"] % candidate["II"], "cycle": boundary["cycle"],
        })
        counts["constant"] += 1
    records.append({
        "record_class": "launch", "II": candidate["II"],
        "compute_nodes": len(candidate["node_records"]), "predicate": candidate["predicate"],
    })
    counts["launch"] = 1
    blob = b"".join(canonical_bytes(record) for record in records)
    summary = {
        "status": "success",
        "records": len(records),
        "bytes": len(blob),
        "compute_records": counts["compute"],
        "route_records": counts["route"],
        "register_records": counts["register"],
        "constant_records": counts["constant"],
        "launch_records": 1,
        "prologue_records": 0,
        "required_successful_handshakes": len(records),
    }
    return summary, blob
