"""Lexicographic exact routing via loop-erased suffix feasibility."""
from bounded_route import ExactRoute, route_step


class PolynomialRoute(ExactRoute):
    def solve(self, source):
        if self.end - self.start <= self.ii:
            return self.exact_tail(self.start, source)
        mask_origin = self.start
        reach = self.backward(mask_origin, account_for_prefix=True)
        if not reach[0] & (1 << source):
            return None
        path = []
        tile = source
        for cycle in range(self.start, self.end):
            if self.end - cycle <= self.ii:
                tail = self.exact_tail(cycle, tile)
                assert tail is not None
                return path + tail
            phase = cycle % self.ii
            next_mask = reach[cycle + 1 - mask_origin]
            for hop in self.allowed[phase][tile]:
                destination, channel, _ = hop
                if not next_mask & (1 << destination) or not self.local_allows(phase, tile, hop):
                    continue
                if channel is not None:
                    self.reserve(cycle, tile, hop)
                    # Additional prefix reservation only affects repeated future phases.
                    trial = self.backward(cycle + 1, account_for_prefix=True)
                    if not trial[0] & (1 << destination):
                        self.undo(cycle, tile, hop)
                        continue
                    reach = trial
                    mask_origin = cycle + 1
                path.append(route_step(cycle, tile, destination))
                tile = destination
                break
            else:
                raise AssertionError("a feasible prefix always has a feasible next hop")
        return path


def route_exact_steps(source_tile, target_tile, launch, arrival, ii, reserved_channels, reserved_inputs, output_counts):
    if arrival < launch:
        return None
    return PolynomialRoute(launch, arrival, target_tile, ii, reserved_channels, reserved_inputs, output_counts).solve(source_tile)
