#!/usr/bin/env python3
"""Deterministic criticality-first chronological-II baseline implementation."""

from collections import defaultdict, deque
from copy import deepcopy
from pathlib import Path
import argparse
import json

from core import (
    candidate_shell,
    check_candidate,
    graph_parts,
    load_json,
    mesh_port,
    neighbor_tiles,
    route_step,
    sha256_path,
    topological_metrics,
)


def source_fingerprint():
    import hashlib
    payload = json.dumps(
        {
            "deterministic_baseline.py": sha256_path(__file__),
            "core.py": sha256_path(Path(__file__).resolve().parent / "core.py"),
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("ascii")
    return hashlib.sha256(payload).hexdigest()


def transition_allowed(
    source,
    destination,
    cycle,
    ii,
    reserved_channels,
    reserved_inputs,
    output_counts,
    local_channels,
    local_inputs,
    local_output_counts,
):
    output, input_port, channel = mesh_port(source, destination)
    if output == "LOCAL_RF":
        return True
    phase = cycle % ii
    if (phase, channel) in reserved_channels or (phase, channel) in local_channels:
        return False
    if (phase, destination, input_port) in reserved_inputs or (phase, destination, input_port) in local_inputs:
        return False
    if output_counts[(phase, source)] + local_output_counts.get((phase, source), 0) >= 2:
        return False
    return True


def route_exact_steps(source_tile, target_tile, launch, arrival, ii, reserved_channels, reserved_inputs, output_counts):
    steps_required = arrival - launch
    if steps_required < 0:
        return None
    queue = deque([(launch, source_tile, [], frozenset(), frozenset(), tuple())])
    visited = {(launch, source_tile, frozenset(), frozenset(), tuple())}
    while queue:
        cycle, tile, steps, local_channels, local_inputs, local_output_rows = queue.popleft()
        local_output_counts = dict(local_output_rows)
        if cycle == arrival:
            if tile == target_tile:
                return steps
            continue
        remaining = arrival - cycle
        tx, ty = target_tile % 4, target_tile // 4
        x, y = tile % 4, tile // 4
        if abs(tx - x) + abs(ty - y) > remaining:
            continue
        transitions = [(tile, "LOCAL_RF")] + [(neighbor, "MESH") for neighbor in neighbor_tiles(tile)]
        transitions.sort(key=lambda row: (row[0], row[1]))
        for destination, _ in transitions:
            if not transition_allowed(
                tile,
                destination,
                cycle,
                ii,
                reserved_channels,
                reserved_inputs,
                output_counts,
                local_channels,
                local_inputs,
                local_output_counts,
            ):
                continue
            next_channels = set(local_channels)
            next_inputs = set(local_inputs)
            next_output_counts = dict(local_output_counts)
            output, input_port, channel = mesh_port(tile, destination)
            if output != "LOCAL_RF":
                phase = cycle % ii
                next_channels.add((phase, channel))
                next_inputs.add((phase, destination, input_port))
                next_output_counts[(phase, tile)] = next_output_counts.get((phase, tile), 0) + 1
            frozen_channels = frozenset(next_channels)
            frozen_inputs = frozenset(next_inputs)
            frozen_outputs = tuple(sorted(next_output_counts.items()))
            state = (cycle + 1, destination, frozen_channels, frozen_inputs, frozen_outputs)
            if state in visited:
                continue
            visited.add(state)
            queue.append((cycle + 1, destination, steps + [route_step(cycle, tile, destination)], frozen_channels, frozen_inputs, frozen_outputs))
    return None


def reserve_steps(steps, ii, reserved_channels, reserved_inputs, output_counts):
    changes = []
    for step in steps:
        if step["output_port"] == "LOCAL_RF":
            continue
        cycle = step["cycle"]
        phase = cycle % ii
        destination = int(step["channel_id"].split(":")[3])
        channel_key = (phase, step["channel_id"])
        input_key = (phase, destination, step["input_port"])
        output_key = (phase, step["tile_id"])
        reserved_channels[channel_key] = True
        reserved_inputs[input_key] = True
        output_counts[output_key] += 1
        changes.append((channel_key, input_key, output_key))
    return changes


def rollback(changes, reserved_channels, reserved_inputs, output_counts):
    for channel_key, input_key, output_key in reversed(changes):
        reserved_channels.pop(channel_key, None)
        reserved_inputs.pop(input_key, None)
        output_counts[output_key] -= 1


def deterministic_map(graph, graph_file_sha256, ii):
    metrics = topological_metrics(graph)
    _, compute, _ = graph_parts(graph)
    incoming = defaultdict(list)
    indegree = dict.fromkeys(compute, 0)
    successors = defaultdict(list)
    for edge in graph["edges"]:
        if edge["src"] in compute and edge["dst"] in compute:
            incoming[edge["dst"]].append(edge)
            successors[edge["src"]].append(edge["dst"])
            indegree[edge["dst"]] += 1
    placement = {}
    phase_tiles = {}
    edge_records = {}
    reserved_channels = {}
    reserved_inputs = {}
    output_counts = defaultdict(int)

    def priority(node):
        return (
            metrics["mobility"][node],
            -metrics["remaining_critical_path"][node],
            -metrics["fanout"][node],
            node,
        )

    ready = sorted([node for node, degree in indegree.items() if degree == 0], key=priority)
    while ready:
        node = ready.pop(0)
        earliest = metrics["asap"][node]
        if incoming[node]:
            earliest = max(earliest, max(placement[edge["src"]][0] + 1 for edge in incoming[node]))
        chosen = None
        for absolute_time in range(earliest, earliest + ii):
            phase = absolute_time % ii
            for tile in range(16):
                if (phase, tile) in phase_tiles:
                    continue
                temporary_edges = []
                temporary_changes = []
                feasible = True
                for edge in sorted(incoming[node], key=lambda row: row["id"]):
                    source_time, source_tile = placement[edge["src"]]
                    launch = source_time + 1
                    steps = route_exact_steps(
                        source_tile, tile, launch, absolute_time, ii,
                        reserved_channels, reserved_inputs, output_counts,
                    )
                    if steps is None:
                        feasible = False
                        break
                    changes = reserve_steps(steps, ii, reserved_channels, reserved_inputs, output_counts)
                    temporary_changes.extend(changes)
                    route_kind = "DIRECT" if not steps else ("LOCAL_RF" if all(step["output_port"] == "LOCAL_RF" for step in steps) else "MESH")
                    temporary_edges.append({
                        "edge_id": edge["id"], "src": edge["src"], "dst": edge["dst"], "operand": edge["operand"],
                        "distance": edge["distance"], "predicate": edge["predicate"],
                        "launch_time": launch, "arrival_time": absolute_time,
                        "route_kind": route_kind, "route_steps": steps,
                    })
                if feasible:
                    chosen = (absolute_time, tile, temporary_edges)
                    break
                rollback(temporary_changes, reserved_channels, reserved_inputs, output_counts)
            if chosen is not None:
                break
        if chosen is None:
            return {
                "status": "unscheduled",
                "reason": "no precedence/routing/resource candidate in the registered II-sized chronological window",
                "failed_node": node,
                "scheduled_nodes": len(placement),
                "II": ii,
            }
        absolute_time, tile, temporary_edges = chosen
        placement[node] = (absolute_time, tile)
        phase_tiles[(absolute_time % ii, tile)] = node
        for edge in temporary_edges:
            edge_records[edge["edge_id"]] = edge
        for target in sorted(successors[node]):
            indegree[target] -= 1
            if indegree[target] == 0:
                ready.append(target)
        ready.sort(key=priority)

    node_records = []
    for node in sorted(compute):
        absolute_time, tile = placement[node]
        saved = compute[node]
        node_records.append({
            "node_id": node, "original_node_id": node, "kind": saved["kind"], "opcode": saved["opcode"],
            "latency": saved["latency"],
            "tile_id": tile, "phase": absolute_time % ii, "absolute_time": absolute_time,
            "iteration_index": absolute_time // ii,
        })
    candidate = candidate_shell(
        graph, graph_file_sha256, "D_deterministic", ii, node_records,
        [edge_records[key] for key in sorted(edge_records)], source_fingerprint(),
    )
    checker = check_candidate(graph, candidate)
    return {
        "status": "success" if checker["status"] == "pass" else "illegal",
        "candidate": candidate,
        "checker": checker,
        "priority": ["mobility_ascending", "remaining_critical_path_descending", "fanout_descending", "node_id_lexicographic_ascending"],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--graph", required=True)
    parser.add_argument("--ii", required=True, type=int)
    args = parser.parse_args()
    path = Path(args.graph)
    print(json.dumps(deterministic_map(load_json(path), sha256_path(path), args.ii), sort_keys=True))


if __name__ == "__main__":
    main()
