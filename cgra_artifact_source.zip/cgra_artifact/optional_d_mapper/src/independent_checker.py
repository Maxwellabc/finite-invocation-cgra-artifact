#!/usr/bin/env python3
"""Independent common legality checker; does not import the implementation core."""

from collections import defaultdict
import math


def relation(left, right):
    if not (0 <= left < 16 and 0 <= right < 16):
        return None
    if left == right:
        return "LOCAL_RF"
    lx, ly = left % 4, left // 4
    rx, ry = right % 4, right // 4
    return "MESH" if abs(lx - rx) + abs(ly - ry) == 1 else None


def destination(step):
    if step.get("output_port") == "LOCAL_RF":
        return step.get("tile_id")
    fields = str(step.get("channel_id", "")).split(":")
    if len(fields) != 4 or fields[0] != "mesh":
        return None
    try:
        return int(fields[3])
    except ValueError:
        return None


def expected_ports(left, right):
    if left == right:
        return "LOCAL_RF", "LOCAL_RF", f"local:{left}"
    lx, ly = left % 4, left // 4
    rx, ry = right % 4, right // 4
    if rx == lx + 1:
        output = "EAST"
    elif rx == lx - 1:
        output = "WEST"
    elif ry == ly + 1:
        output = "NORTH"
    elif ry == ly - 1:
        output = "SOUTH"
    else:
        return None
    opposite = {"NORTH": "SOUTH", "SOUTH": "NORTH", "EAST": "WEST", "WEST": "EAST"}[output]
    return output, opposite, f"mesh:{left}:{output}:{right}"


def local_segments(edge):
    segments = []
    current = None
    for step in edge.get("route_steps", []):
        if step.get("output_port") != "LOCAL_RF":
            if current is not None:
                segments.append(current)
                current = None
            continue
        tile = step.get("tile_id")
        cycle = step.get("cycle")
        if current is None or current["tile"] != tile or current["end"] != cycle:
            if current is not None:
                segments.append(current)
            current = {"tile": tile, "start": cycle, "end": cycle + 1}
        else:
            current["end"] = cycle + 1
    if current is not None:
        segments.append(current)
    return segments


def phases_for(start, end, ii, versions, lane):
    del versions, lane
    return sorted({(start + offset) % ii for offset in range(end - start)})


def periodic_conflict(left, right):
    if left["tile_id"] != right["tile_id"]:
        return False
    difference = left["occupancy_window_start"] - right["occupancy_window_start"]
    modulus = math.gcd(left["period_cycles"], right["period_cycles"])
    minimum = -left["lifetime_cycles"] + 1
    maximum = right["lifetime_cycles"] - 1
    first = minimum + ((difference - minimum) % modulus)
    return first <= maximum


def check(graph, candidate):
    failures = []
    checks = 0

    def require(code, condition, detail=None):
        nonlocal checks
        checks += 1
        if not condition:
            failures.append({"code": code, "detail": detail})

    graph_node_rows = graph.get("nodes", [])
    nodes = {row.get("id"): row for row in graph_node_rows}
    compute = {key: row for key, row in nodes.items() if not row.get("zero_resource", False)}
    boundary = {key: row for key, row in nodes.items() if row.get("zero_resource", False)}
    require("graph_schema", graph.get("schema_version") == 1)
    require("graph_node_unique", len(nodes) == len(graph_node_rows))
    require("candidate_schema", candidate.get("schema_version") == 1)
    require("candidate_circuit", candidate.get("circuit") == graph.get("circuit"))
    require("candidate_arm", candidate.get("arm") in {"A_current", "B_upstream", "D_deterministic"})
    require("candidate_graph_hash", candidate.get("canonical_graph_sha256") == graph.get("canonical_graph_sha256"))
    require("candidate_hardware_hash", candidate.get("hardware_contract_sha256") == graph.get("hardware_contract_sha256"))
    fingerprint = candidate.get("source_fingerprint")
    require("candidate_source_fingerprint", isinstance(fingerprint, str) and len(fingerprint) == 64 and all(ch in "0123456789abcdef" for ch in fingerprint))
    require("candidate_seed", candidate.get("seed_policy") == {"python_hash_seed": 0, "z3_smt_random_seed": 0, "z3_sat_random_seed": 0})
    arity = {"AND": 2, "NOT": 1}
    opcode = {"AND": 10, "NOT": 11}
    operands = defaultdict(set)
    graph_edge_rows = graph.get("edges", [])
    graph_edge_ids = [row.get("id") for row in graph_edge_rows]
    require("graph_edge_unique", len(graph_edge_ids) == len(set(graph_edge_ids)))
    for node_id, row in compute.items():
        kind = row.get("kind")
        require(f"graph_node:{node_id}:kind", kind in arity)
        require(f"graph_node:{node_id}:opcode", kind in opcode and row.get("opcode") == opcode[kind])
        require(f"graph_node:{node_id}:latency", row.get("latency") == 1)
        require(f"graph_node:{node_id}:resource", row.get("resource") == "LogicRTL")
        require(f"graph_node:{node_id}:predicate", row.get("predicate") is True)
    for edge in graph_edge_rows:
        require(f"graph_edge:{edge.get('id')}:endpoints", edge.get("src") in nodes and edge.get("dst") in nodes)
        require(f"graph_edge:{edge.get('id')}:contract", edge.get("distance") == 0 and edge.get("predicate") is True)
        if edge.get("dst") in compute:
            operands[edge["dst"]].add(edge.get("operand"))
    for node_id, row in compute.items():
        if row.get("kind") in arity:
            require(f"graph_node:{node_id}:operands", operands[node_id] == set(range(arity[row["kind"]])))
    ii = candidate.get("II")
    require("ii", type(ii) is int and ii > 0)
    if type(ii) is not int or ii < 1:
        return {"status": "fail", "checks": checks, "failures": failures}
    node_rows = candidate.get("node_records", [])
    placed = {row.get("node_id"): row for row in node_rows}
    require("node_set", set(placed) == set(compute))
    require("node_unique", len(placed) == len(node_rows))
    occupied = {}
    for node_id, row in placed.items():
        if node_id not in compute:
            continue
        tile = row.get("tile_id")
        absolute = row.get("absolute_time")
        phase = row.get("phase")
        require(f"node:{node_id}:tile", type(tile) is int and 0 <= tile < 16)
        require(f"node:{node_id}:time", type(absolute) is int and absolute >= 0)
        require(f"node:{node_id}:phase", type(absolute) is int and type(phase) is int and phase == absolute % ii)
        require(f"node:{node_id}:original", row.get("original_node_id") == node_id)
        require(f"node:{node_id}:iteration", type(absolute) is int and row.get("iteration_index") == absolute // ii)
        require(f"node:{node_id}:kind", row.get("kind") == compute[node_id].get("kind"))
        require(f"node:{node_id}:opcode", row.get("opcode") == compute[node_id].get("opcode"))
        require(f"node:{node_id}:latency", row.get("latency") == compute[node_id].get("latency"))
        if type(phase) is int and type(tile) is int:
            key = (phase, tile)
            require(f"node:{node_id}:occupancy", key not in occupied, occupied.get(key))
            occupied[key] = node_id

    graph_edges = {row["id"]: row for row in graph.get("edges", []) if row["src"] in compute and row["dst"] in compute}
    saved_edges = candidate.get("edge_records", [])
    routed = {row.get("edge_id"): row for row in saved_edges}
    require("edge_set", set(routed) == set(graph_edges))
    require("edge_unique", len(routed) == len(saved_edges))
    channels = set()
    inputs = set()
    output_counts = defaultdict(int)
    route_hops = 0
    port_conflicts = 0
    predicate_violations = 0
    for edge_id, row in routed.items():
        if edge_id not in graph_edges or row.get("src") not in placed or row.get("dst") not in placed:
            continue
        edge = graph_edges[edge_id]
        source = placed[row["src"]]
        target = placed[row["dst"]]
        launch = source["absolute_time"] + 1
        arrival = target["absolute_time"]
        identity_ok = all(row.get(key) == edge.get(key) for key in ["src", "dst", "operand", "distance", "predicate"])
        if row.get("predicate") is not edge.get("predicate"):
            predicate_violations += 1
        require(f"edge:{edge_id}:identity", identity_ok)
        require(f"edge:{edge_id}:launch", row.get("launch_time") == launch)
        require(f"edge:{edge_id}:arrival", row.get("arrival_time") == arrival and arrival >= launch)
        steps = row.get("route_steps", [])
        require(f"edge:{edge_id}:length", len(steps) == arrival - launch)
        tile = source["tile_id"]
        for offset, step in enumerate(steps):
            cycle = launch + offset
            require(f"edge:{edge_id}:{offset}:cycle", step.get("cycle") == cycle)
            require(f"edge:{edge_id}:{offset}:source", step.get("tile_id") == tile)
            next_tile = destination(step)
            kind = relation(tile, next_tile) if next_tile is not None else None
            require(f"edge:{edge_id}:{offset}:relation", kind in {"MESH", "LOCAL_RF"})
            ports = expected_ports(tile, next_tile) if kind is not None else None
            require(f"edge:{edge_id}:{offset}:ports", ports is not None and tuple(step.get(key) for key in ["output_port", "input_port", "channel_id"]) == ports)
            if kind == "MESH":
                route_hops += 1
                phase = cycle % ii
                channel_key = (phase, step["channel_id"])
                input_key = (phase, next_tile, step["input_port"])
                if channel_key in channels or input_key in inputs or output_counts[(phase, tile)] >= 2:
                    port_conflicts += 1
                require(f"edge:{edge_id}:{offset}:channel", channel_key not in channels)
                require(f"edge:{edge_id}:{offset}:input", input_key not in inputs)
                output_counts[(phase, tile)] += 1
                require(f"edge:{edge_id}:{offset}:outputs", output_counts[(phase, tile)] <= 2)
                channels.add(channel_key)
                inputs.add(input_key)
            if next_tile is not None:
                tile = next_tile
        require(f"edge:{edge_id}:target", tile == target["tile_id"])
        route_kind = "DIRECT" if not steps else ("LOCAL_RF" if all(step.get("output_port") == "LOCAL_RF" for step in steps) else "MESH")
        require(f"edge:{edge_id}:route_kind", row.get("route_kind") == route_kind)

    expected_items = {}
    for edge_id, row in routed.items():
        for segment_index, segment in enumerate(local_segments(row)):
            lifetime = segment["end"] - segment["start"]
            versions = max(1, math.ceil(lifetime / ii))
            for lane in range(versions):
                item_id = f"{edge_id}@{segment['tile']}:{segment_index}:v{lane}"
                expected_items[item_id] = {
                    "edge_id": edge_id,
                    "value_id": edge_id,
                    "version": lane,
                    "tile_id": segment["tile"],
                    "write_time": segment["start"] + lane * ii,
                    "read_times": [segment["end"] + lane * ii],
                    "last_writer_node": row["src"],
                    "lifetime_cycles": lifetime,
                    "period_cycles": versions * ii,
                    "occupancy_window_start": segment["start"] + lane * ii,
                    "occupancy_window_end": segment["end"] + lane * ii,
                    "occupancy_phases": phases_for(segment["start"], segment["end"], ii, versions, lane),
                }
    register_rows = candidate.get("register_records", [])
    actual_items = {row.get("item_id"): row for row in register_rows}
    require("register_set", set(actual_items) == set(expected_items))
    require("register_unique", len(actual_items) == len(register_rows))
    assigned_slots = defaultdict(list)
    register_violations = 0
    for item_id, expected in expected_items.items():
        row = actual_items.get(item_id)
        if row is None:
            register_violations += 1
            continue
        for key, value in expected.items():
            if row.get(key) != value:
                register_violations += 1
            require(f"register:{item_id}:{key}", row.get(key) == value)
        bank = row.get("bank")
        index = row.get("index")
        bank_ok = isinstance(bank, int) and not isinstance(bank, bool) and 0 <= bank < 4
        index_ok = isinstance(index, int) and not isinstance(index, bool) and 0 <= index < 8
        if not bank_ok or not index_ok:
            register_violations += 1
        require(f"register:{item_id}:bank", bank_ok)
        require(f"register:{item_id}:index", index_ok)
        if bank_ok and index_ok:
            assigned_slots[(row["tile_id"], bank, index)].append(item_id)
    for slot, item_ids in sorted(assigned_slots.items()):
        for left_index, left_id in enumerate(sorted(item_ids)):
            for right_id in sorted(item_ids)[left_index + 1:]:
                conflict = periodic_conflict(expected_items[left_id], expected_items[right_id])
                if conflict:
                    register_violations += 1
                require(f"register_conflict:{slot}:{left_id}:{right_id}", not conflict)

    expected_boundary = []
    for edge in sorted(graph.get("edges", []), key=lambda item: item["id"]):
        if edge["src"] in boundary and edge["dst"] in compute and edge["dst"] in placed:
            target = placed[edge["dst"]]
            expected_boundary.append({
                "boundary_node_id": edge["src"], "kind": nodes[edge["src"]]["kind"], "edge_id": edge["id"],
                "operand": edge["operand"], "tile_id": target["tile_id"], "port": f"FU_IN_{edge['operand']}",
                "cycle": target["absolute_time"], "direction": "ingress",
                "value": nodes[edge["src"]].get("value") if nodes[edge["src"]]["kind"] == "CONST" else None,
            })
        elif edge["src"] in compute and edge["dst"] in boundary and edge["src"] in placed:
            source = placed[edge["src"]]
            expected_boundary.append({
                "boundary_node_id": edge["dst"], "kind": nodes[edge["dst"]]["kind"], "edge_id": edge["id"],
                "operand": edge["operand"], "tile_id": source["tile_id"], "port": "FU_OUT",
                "cycle": source["absolute_time"] + 1, "direction": "egress", "value": None,
            })
    boundary_ok = candidate.get("boundary_records", []) == expected_boundary
    require("boundary", boundary_ok)
    predicate_ok = candidate.get("predicate") == "always_true"
    require("predicate", predicate_ok)
    if not predicate_ok:
        predicate_violations += 1
    return {
        "status": "pass" if not failures else "fail",
        "checks": checks,
        "failures": failures,
        "route_hops": route_hops,
        "port_conflicts": port_conflicts,
        "register_violations": register_violations + (0 if set(actual_items) == set(expected_items) else 1),
        "fifo_violations": 0,
        "predicate_violations": predicate_violations,
        "boundary_violations": 0 if boundary_ok else 1,
        "failure_records": failures,
    }
