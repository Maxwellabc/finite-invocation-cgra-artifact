"""Exact-step lexicographic router with bounded live search state."""
from core import mesh_port, neighbor_tiles, route_step

TILE_COUNT = 16


def mesh_choices(tile):
    for destination in sorted([tile, *neighbor_tiles(tile)]):
        output, input_port, channel = mesh_port(tile, destination)
        yield (destination, None, None) if output == "LOCAL_RF" else (destination, channel, input_port)


CHOICES = tuple(tuple(mesh_choices(tile)) for tile in range(TILE_COUNT))
# A directed cardinal channel names its destination ingress exactly.
assert sum(hop[1] is not None for hops in CHOICES for hop in hops) == len({
    (destination, ingress)
    for hops in CHOICES
    for destination, channel, ingress in hops
    if channel is not None
})


def phase_choices(phase, channels, inputs, outputs):
    return tuple(tuple(
        hop for hop in hops
        if hop[1] is None
        or ((phase, hop[1]) not in channels and (phase, hop[0], hop[2]) not in inputs
            and outputs.get((phase, tile), 0) < 2)
    ) for tile, hops in enumerate(CHOICES))


class ExactRoute:
    def __init__(self, start, end, target, ii, channels, inputs, outputs):
        self.start = start
        self.end = end
        self.target = target
        self.ii = ii
        self.base_outputs = outputs
        self.allowed = {
            phase: phase_choices(phase, channels, inputs, outputs)
            for phase in {cycle % ii for cycle in range(start, min(end, start + ii))}
        }
        self.local_channels = set()
        self.local_outputs = {}

    def local_allows(self, phase, tile, hop):
        _, channel, _ = hop
        if channel is None:
            return True
        key = (phase, tile)
        return ((phase, channel) not in self.local_channels
                and self.base_outputs.get(key, 0) + self.local_outputs.get(key, 0) < 2)

    def backward(self, start, *, account_for_prefix):
        """Global-only relaxation or exact unique-phase suffix reachability."""
        masks = [0] * (self.end - start + 1)
        masks[-1] = 1 << self.target
        for cycle in range(self.end - 1, start - 1, -1):
            phase = cycle % self.ii
            reachable = masks[cycle - start + 1]
            mask = 0
            for tile, hops in enumerate(self.allowed[phase]):
                if any(reachable & (1 << hop[0]) and
                       (not account_for_prefix or self.local_allows(phase, tile, hop))
                       for hop in hops):
                    mask |= 1 << tile
            masks[cycle - start] = mask
        return masks

    def exact_tail(self, cycle, tile):
        # In at most II slots, no suffix phase is reused internally.
        masks = self.backward(cycle, account_for_prefix=True)
        if not masks[0] & (1 << tile):
            return None
        path = []
        for index, edge_cycle in enumerate(range(cycle, self.end)):
            phase = edge_cycle % self.ii
            hop = next(hop for hop in self.allowed[phase][tile]
                       if masks[index + 1] & (1 << hop[0]) and self.local_allows(phase, tile, hop))
            path.append(route_step(edge_cycle, tile, hop[0]))
            tile = hop[0]
        return path

    def reserve(self, cycle, tile, hop):
        channel = hop[1]
        if channel is not None:
            phase = cycle % self.ii
            self.local_channels.add((phase, channel))
            key = (phase, tile)
            self.local_outputs[key] = self.local_outputs.get(key, 0) + 1

    def undo(self, cycle, tile, hop):
        channel = hop[1]
        if channel is not None:
            phase = cycle % self.ii
            self.local_channels.remove((phase, channel))
            key = (phase, tile)
            self.local_outputs[key] -= 1
            if not self.local_outputs[key]:
                del self.local_outputs[key]

    def solve(self, source):
        if self.end - self.start <= self.ii:
            return self.exact_tail(self.start, source)
        relaxed = self.backward(self.start, account_for_prefix=False)
        if not relaxed[0] & (1 << source):
            return None
        suffix_start = self.end - self.ii
        path = []
        frames = [(self.start, source, iter(self.allowed[self.start % self.ii][source]))]
        while frames:
            cycle, tile, candidates = frames[-1]
            hop = next(candidates, None)
            if hop is None:
                frames.pop()
                if path:
                    self.undo(*path.pop())
                continue
            destination = hop[0]
            phase = cycle % self.ii
            if not relaxed[cycle - self.start + 1] & (1 << destination) or not self.local_allows(phase, tile, hop):
                continue
            self.reserve(cycle, tile, hop)
            path.append((cycle, tile, hop))
            if cycle + 1 == suffix_start:
                tail = self.exact_tail(cycle + 1, destination)
                if tail is not None:
                    return [route_step(c, u, move[0]) for c, u, move in path] + tail
                self.undo(*path.pop())
            else:
                frames.append((cycle + 1, destination, iter(self.allowed[(cycle + 1) % self.ii][destination])))
        return None


def route_exact_steps(source_tile, target_tile, launch, arrival, ii, reserved_channels, reserved_inputs, output_counts):
    if arrival < launch:
        return None
    return ExactRoute(launch, arrival, target_tile, ii, reserved_channels, reserved_inputs, output_counts).solve(source_tile)
