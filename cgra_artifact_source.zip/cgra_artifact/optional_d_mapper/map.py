#!/usr/bin/env python3
"""Run one fixed-II common-domain mapping, then independent check and lowering."""
import argparse,base64,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
import core,deterministic_baseline,independent_checker

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--graph',type=Path,required=True)
    p.add_argument('--ii',type=int,required=True)
    p.add_argument('--router',choices=['original','polynomial'],default='polynomial')
    args=p.parse_args()
    if args.ii<1:p.error('--ii must be positive')
    if args.router=='polynomial':
        from polynomial_route import route_exact_steps
        deterministic_baseline.route_exact_steps=route_exact_steps
    data=args.graph.read_bytes();graph=json.loads(data)
    result=deterministic_baseline.deterministic_map(graph,hashlib.sha256(data).hexdigest(),args.ii)
    if result.get('candidate'):
        checked=independent_checker.check(graph,result['candidate'])
        result['independent_checker']=checked
        summary,blob=core.lower_configuration(result['candidate'],checked)
        result['lowering']={'summary':summary,'blob_sha256':None if blob is None else hashlib.sha256(blob).hexdigest(),'blob_base64':None if blob is None else base64.b64encode(blob).decode('ascii')}
    print(json.dumps(result,sort_keys=True))

if __name__=='__main__':main()
