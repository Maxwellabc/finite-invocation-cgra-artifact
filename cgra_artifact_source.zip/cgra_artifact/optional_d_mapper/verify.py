#!/usr/bin/env python3
"""Verify all pinned export files and replay accepted checker/lowerer evidence."""
from pathlib import Path
import base64,hashlib,json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
import core,independent_checker

def load(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=load(ROOT/'SHA256.json')
for name,digest in manifest.items():
    assert sha(ROOT/name)==digest,'hash mismatch '+name
seal=load(ROOT/'seal_manifest.json')
assert seal['sha256_manifest_sha256']==sha(ROOT/'SHA256.json')
assert set(manifest)|{'SHA256.json','seal_manifest.json'}=={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
rows=[]
for folder in sorted((ROOT/'evidence').glob('*')):
    candidate=folder/'candidate.json'
    if not candidate.is_file():continue
    case=folder.name
    graph=ROOT/'graphs'/(case+'.json')
    value=load(candidate)
    assert value['graph_file_sha256']==sha(graph)
    checked=independent_checker.check(load(graph),value)
    assert checked==load(folder/'independent_checker.json')
    assert checked['status']=='pass' and checked['failures']==[]
    summary,blob=core.lower_configuration(value,checked)
    archived=load(folder/'lowering_result.json')
    assert summary==archived['summary'] and blob==base64.b64decode(archived['blob_base64'])
    assert hashlib.sha256(blob).hexdigest()==archived['blob_sha256']
    rows.append({'case':case,'II':value['II'],'checks':checked['checks'],'records':summary['records'],'bytes':summary['bytes']})
rejected=[]
for path in sorted((ROOT/'measurements'/'successor').glob('*/attempts/*/independent_checker.json')):
    archived=load(path)
    if archived['status']!='fail':continue
    case=path.parents[2].name
    candidate=load(path.parent/'candidate.json')
    graph=ROOT/'graphs'/(case+'.json')
    assert candidate['graph_file_sha256']==sha(graph)
    checked=independent_checker.check(load(graph),candidate)
    assert checked==archived and checked['failures']
    rejected.append({'case':case,'II':candidate['II'],'failures':checked['failures'],'register_violations':checked['register_violations']})
assert len(rows)==3 and len(rejected)==17
print(json.dumps({'status':'pass','members_verified':len(manifest),'accepted_candidates_replayed':rows,'rejected_candidates_replayed':rejected,'mapper_calls':0,'EPFL_reads':0},sort_keys=True))
