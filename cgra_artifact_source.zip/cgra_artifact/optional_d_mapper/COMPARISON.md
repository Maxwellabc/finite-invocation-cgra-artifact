| Graph | II window | Original D | Successor D | Attempts old/new | Mapper wall old/new (s) | Peak RSS old/new (MiB) |
|---|---|---|---|---|---|---|
| c17 | 1–9 | success | success II2 | 2/2 | 0.154/0.237 | 78.45/21.20 |
| c432 | 15–23 | crash | success II23 | 9/9 | 347.741/2.726 | 8587.36/24.47 |
| c880 | 35–43 | crash | success II38 | 9/4 | 343.808/1.258 | 8306.38/27.30 |
| c1908 | 37–45 | timeout | UNKNOWN | 9/9 | 1080.539/3.831 | 5773.91/24.80 |
| c1355 | 48–56 | timeout | UNKNOWN | 9/9 | 1080.216/4.065 | 3412.61/25.20 |
| c499 | 50–58 | crash | UNKNOWN | 9/9 | 375.542/4.897 | 8400.97/25.36 |
| c2670 | 64–72 | crash | UNKNOWN | 9/9 | 689.267/8.788 | 8527.55/28.62 |
| c3540 | 96–106 | crash | UNKNOWN | 11/11 | 419.553/34.969 | 8618.59/42.69 |
| c5315 | 145–160 | crash | UNKNOWN | 16/16 | 585.103/1359.785 | 8483.59/41.97 |
| c7552 | 169–186 | crash | UNKNOWN | 18/18 | 1457.898/921.191 | 8535.92/45.94 |
| c6288 | 234–258 | crash | UNKNOWN | 25/25 | 1503.846/142.636 | 8555.20/74.56 |

All statuses use terminal attempt/process receipts. An earlier progress-message inference that c7552 II169 timed out was corrected by its receipt, which records UNKNOWN, timed_out=false, wall44.477572s.
