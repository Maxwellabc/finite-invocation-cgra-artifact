# Editable vector figures

The hand-positioned diagrams and measured-result plots use Matplotlib. From this directory run `python3 draw_figures.py NEW_OUTPUT_DIRECTORY` with an output directory that does not exist. The script creates PDF and SVG files. Fonts, metadata date and SVG identifiers are fixed for deterministic output in the recorded environment. `figure_data.json` preserves the plotted measurements and their scope. It contains archived V22 results, with zero new hardware executions.

The paper uses PDF vector assets. SVG files preserve editable text. Rebuilding graphics requires Matplotlib and its standard dependencies, separately from the standard-library verification suite. The authoring environment used Matplotlib 3.10.7 and the DejaVu Sans fonts shipped with it.
