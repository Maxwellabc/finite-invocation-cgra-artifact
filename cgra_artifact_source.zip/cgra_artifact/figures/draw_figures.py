"""Deterministic hand-positioned vector illustrations and measured-result plots."""
from pathlib import Path
import json, os, sys
os.environ['SOURCE_DATE_EPOCH'] = '1793923200'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 draw_figures.py NEW_OUTPUT_DIRECTORY')
ROOT = Path(sys.argv[1]).resolve()
ROOT.mkdir(exist_ok=False)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8, 'pdf.fonttype': 42, 'svg.fonttype': 'none', 'svg.hashsalt': 'cgra-v23', 'axes.spines.top': False, 'axes.spines.right': False, 'axes.linewidth': 0.6, 'xtick.labelsize': 7, 'ytick.labelsize': 7})
BLUE = '#326287'
ORANGE = '#b76b32'
GREEN = '#407764'
GRAY = '#58616a'

def save(fig, name):
    for ext in ('pdf', 'svg'):
        fig.savefig(ROOT / f'{name}.{ext}', bbox_inches='tight', pad_inches=0.035, metadata={'Creator': 'Matplotlib vector paths'} if ext == 'pdf' else {'Creator': 'Matplotlib vector paths', 'Date': None})
    plt.close(fig)

def box(ax, x, y, w, h, text, color=BLUE, fill='#f5f8fa', fs=7.3):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.03,rounding_size=0.04', linewidth=0.8, edgecolor=color, facecolor=fill))
    ax.text(x + w / 2, y + h / 2, text, ha='center', va='center', fontsize=fs, color='#17212b')

def arrow(ax, x, y, xx, yy, color=GRAY, style='-|>'):
    ax.add_patch(FancyArrowPatch((x, y), (xx, yy), arrowstyle=style, mutation_scale=8, linewidth=0.85, color=color))
(fig, ax) = plt.subplots(figsize=(3.45, 2.15))
ax.set(xlim=(0, 10), ylim=(0, 6.2))
ax.axis('off')
box(ax, 0.08, 4.55, 2.5, 1.05, 'CPU\nserial ingress')
box(ax, 3.1, 4.55, 2.75, 1.05, 'setup packets\n+ LAUNCH', ORANGE, '#fcf7f1')
box(ax, 6.65, 4.55, 3.1, 1.05, 'tile-local state\ninstall before use')
arrow(ax, 2.65, 5.08, 3.02, 5.08)
arrow(ax, 5.92, 5.08, 6.57, 5.08)
for (x, y, t) in [(3.35, 2.65, 'v1'), (5.15, 2.65, 'v2'), (5.15, 0.85, 'RET')]:
    box(ax, x, y, 1.18, 0.8, t, BLUE)
arrow(ax, 4.58, 3.05, 5.07, 3.05)
arrow(ax, 5.74, 2.58, 5.74, 1.72)
ax.text(4.9, 3.85, 'registered mesh / bounded FIFO', ha='center', fontsize=7.5)
arrow(ax, 7.9, 4.5, 6.4, 3.18)
box(ax, 0.1, 0.85, 2.45, 0.8, 'last store W', GREEN, '#f4f9f6')
box(ax, 7.35, 0.85, 2.4, 0.8, 'HOST H', GREEN, '#f4f9f6')
arrow(ax, 6.4, 1.25, 7.27, 1.25, GREEN)
ax.text(7.5, 2.5, 'AUTO', fontsize=7, color=GRAY)
arrow(ax, 8.0, 2.35, 8.5, 1.7, GRAY)
ax.text(4.9, 0.15, 'minimize H  subject to W < H and true-return identity', ha='center', fontsize=7.5)
save(fig, 'problem_contract')
(fig, ax) = plt.subplots(figsize=(3.45, 2.2))
ax.set(xlim=(0, 10), ylim=(0, 6.1))
ax.axis('off')
box(ax, 0.08, 4.75, 4.2, 0.9, 'mapping + cold\nreset contract')
box(ax, 5.45, 4.75, 4.4, 0.9, 'restricted rewrites\nreset elision', ORANGE, '#fcf7f1')
arrow(ax, 4.35, 5.2, 5.38, 5.2)
box(ax, 5.45, 2.95, 4.4, 1.0, 'causal envelope +\nphysical windows')
arrow(ax, 7.65, 4.68, 7.65, 4.02)
box(ax, 0.08, 2.8, 4.2, 1.3, 'tight-prefix selector\n' + '$N(\\tau)=\\tau-j+1$' + '\n' + 'choose $d\\leq\\tau$')
arrow(ax, 5.38, 3.45, 4.35, 3.45)
box(ax, 0.08, 0.95, 4.2, 1.05, 'static admission\nwindows / projection', GREEN, '#f4f9f6')
arrow(ax, 2.18, 2.88, 2.18, 2.07)
box(ax, 5.45, 0.75, 4.4, 1.45, 'native + physical\nstate / FIFO / return\nR, W, H, helper T', GREEN, '#f4f9f6')
arrow(ax, 4.35, 1.47, 5.38, 1.47)
ax.text(5.0, 0.15, 'retain rejected candidates, hashes, seeds and all costs', ha='center', fontsize=7.5)
save(fig, 'method_flow')
(fig, (ax, bx)) = plt.subplots(1, 2, figsize=(7.05, 1.85), gridspec_kw={'width_ratios': [1.13, 1]}, layout='constrained')
names = ['ReLU', 'FIR', 'Hist.', 'AXPY', 'SAD']
base = [316, 328, 215, 294, 182]
new = [307, 315, 196, 268, 168]
pb = [103, 106, 70, 149, 93]
pn = [125, 124, 69, 123, 79]
ax.scatter([100 * n / b for (n, b) in zip(pn, pb)], [100 * n / b for (n, b) in zip(new, base)], s=24, color=BLUE, zorder=3)
for (i, label) in enumerate(names):
    ax.annotate(label, (100 * pn[i] / pb[i], 100 * new[i] / base[i]), xytext=(4, 3 if i != 2 else -9), textcoords='offset points', fontsize=7)
ax.axvline(100, color=GRAY, lw=0.65, ls='--')
ax.axhline(100, color=GRAY, lw=0.65, ls='--')
ax.set(xlim=(76, 128), ylim=(89, 101), xlabel='configuration packets (% of paired control)', ylabel='helper cycles (% of paired control)')
ax.text(0.02, 0.98, '(a) Finite invocation trade-off', transform=ax.transAxes, va='top', fontsize=8, bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': 1})
bx.plot([8, 16, 24, 32], [206, 246, 286, 316], marker='o', ms=3, lw=1, color=GRAY, label='II5, strong control')
bx.plot([8, 16, 24, 32], [211, 243, 275, 307], marker='s', ms=3, lw=1, color=BLUE, label='II4, selected order')
bx.set(xlabel='ReLU invocation length N', ylabel='helper cycles', xticks=[8, 16, 24, 32], ylim=(190, 345))
bx.legend(frameon=False, fontsize=7, loc='upper left')
bx.text(0.98, 0.98, '(b) Length sensitivity', transform=bx.transAxes, va='top', ha='right', fontsize=8)
save(fig, 'invocation_results')
(fig, (ax, bx)) = plt.subplots(1, 2, figsize=(3.45, 1.65), layout='constrained')
x = [5, 6, 7]
ax.plot(x, [44, 55, 52], marker='o', ms=3, lw=1, color=GRAY, label='adapted SAT')
ax.plot(x, [39, 44, 49], marker='s', ms=3, lw=1, color=BLUE, label='joint')
ax.plot(x, [39, 44, 49], marker='x', ms=5, lw=0, color=ORANGE, label='work floor')
ax.set(xlabel='tree nodes', ylabel='true HOST cycles', xticks=x, ylim=(35, 60))
ax.legend(frameon=False, fontsize=5.8, loc='upper left')
labels = ['Affine5', 'Offset7', 'Diamond6']
g = [46, 55, 46]
l = [44, 52, 45]
for (yy, a, b) in zip([2, 1, 0], g, l):
    bx.plot([b, a], [yy, yy], color=GRAY, lw=0.8)
    bx.text(a + 0.4, yy, str(a), va='center', fontsize=6)
    bx.text(b - 0.5, yy, str(b), va='center', ha='right', fontsize=6)
bx.scatter(g, [2, 1, 0], s=16, color=GRAY, label='global')
bx.scatter(l, [2, 1, 0], s=16, color=BLUE, marker='s', label='tile-local')
bx.set(xlim=(38, 60), yticks=[2, 1, 0], yticklabels=labels, xlabel='true HOST cycles')
bx.legend(frameon=False, fontsize=5.8, loc='upper left', bbox_to_anchor=(0, 1.25), ncol=2, handletextpad=0.3, columnspacing=0.6)
save(fig, 'certified_results')
(ROOT / 'figure_data.json').write_text(json.dumps({'provenance': 'V22 sealed Tables I/II and Section 5, no new executions', 'applications': {'names': names, 'baseline_T': base, 'selected_T': new, 'baseline_packets': pb, 'selected_packets': pn}, 'length': {'N': [8, 16, 24, 32], 'II5_T': [206, 246, 286, 316], 'II4_T': [211, 243, 275, 307]}, 'dedicated_H': {'nodes': [5, 6, 7], 'adapted_SAT': [44, 55, 52], 'joint_and_floor': [39, 44, 49]}, 'fences_H': {'labels': labels, 'global': g, 'local': l}}, indent=2) + '\n')
