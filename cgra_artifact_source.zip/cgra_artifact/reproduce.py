"""Check immutable archive pins and run each portable verification entry point."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile
import time
import zipfile

ROOT = Path(__file__).resolve().parent

def main():
    started = time.perf_counter()
    destination = Path(tempfile.mkdtemp(prefix='reproduction-output-', dir=ROOT))
    entries = json.loads((ROOT / 'archive_manifest.json').read_text())
    results = []
    for entry in entries:
        archive = ROOT / 'archives' / entry['file']
        if hashlib.sha256(archive.read_bytes()).hexdigest() != entry['sha256']:
            raise ValueError('Archive digest mismatch: ' + entry['file'])
        extraction = destination / archive.stem
        extraction.mkdir(exist_ok=False)
        with zipfile.ZipFile(archive) as package:
            for member in package.infolist():
                path = Path(member.filename)
                if path.is_absolute() or '..' in path.parts or member.external_attr >> 16 & 0o170000 == 0o120000:
                    raise ValueError('Unsafe archive member')
            package.extractall(extraction)
        entry_points = {
            'cgra_host_schedule_replay.zip': ('cgra_host_replay', 'replay.py', True),
            'cgra_v23_barrier_portable.zip': ('cgra_barrier', 'verify.py', False),
        }
        folder, script, isolated = entry_points.get(archive.name, ('', 'reproduce.py', False))
        working = extraction / folder
        command = [sys.executable]
        if isolated:
            command.append('-I')
        command.extend(['-B', script])
        before = time.perf_counter()
        with (destination / (archive.stem + '.stdout.log')).open('xb') as output, (destination / (archive.stem + '.stderr.log')).open('xb') as errors:
            completed = subprocess.run(command, cwd=working, stdout=output, stderr=errors, timeout=1800)
        returncode = completed.returncode
        if archive.name == 'cgra_v23_barrier_portable.zip' and returncode == 0:
            actual = json.loads((destination / (archive.stem + '.stdout.log')).read_text())
            expected = json.loads((working / 'expected_result.json').read_text())
            for variable in ('timings', 'wall_seconds', 'cpu_seconds', 'peak_rss_bytes'):
                actual.pop(variable, None)
                expected.pop(variable, None)
            if actual != expected:
                returncode = 1
        results.append({'archive': archive.name, 'returncode': returncode,
                        'fresh_wall_seconds': time.perf_counter() - before,
                        'command': command[1:], 'saved_log': str(extraction.relative_to(ROOT))})
        print(archive.name, 'PASS' if returncode == 0 else 'FAIL', flush=True)
    record = {'status': 'PASS_ALL_PORTABLE_PACKAGES' if all(row['returncode'] == 0 for row in results) else 'FAIL',
              'python': sys.version, 'results': results,
              'fresh_total_wall_seconds': time.perf_counter() - started}
    (destination / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))
    return 0 if record['status'] == 'PASS_ALL_PORTABLE_PACKAGES' else 1

if __name__ == '__main__':
    sys.exit(main())
