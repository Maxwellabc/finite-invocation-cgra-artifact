# Finite-invocation CGRA verification artifact

Portable verification code and archived evidence for *Finite-Invocation Mapping and Configuration for Tokenized CGRAs*.

## Run the portable suite

Use CPython 3.9 or later with its standard library. From this directory run

```sh
python3 -I -B reproduce.py
```

The driver verifies archive SHA-256 hashes before extraction, uses a fresh output directory for every invocation, runs all six packages, retains each output/error log and reports fresh wall times. A complete successful run ends with `PASS_ALL_PORTABLE_PACKAGES`. Exact timing depends on host and interpreter. The underlying packages report their own verification counts and statuses. A failing package remains in the result and causes a nonzero exit after the other packages finish.

## What is checked

| Package | Verification scope |
|---|---|
| theory reproduction | Guarded LAUNCH exact feasibility, independent exhaustive oracle and archived stripe identities |
| guarded window heads | 196,920 abstract cases, complete head sets and twelve frozen AXPY static repairs |
| dynamic packet windows | Dynamic-head certificates, arbitrary windows and optional idle, exhaustive and seeded cases |
| application evidence | All 39 Table I confirmation executions reconstructed from saved trace projections, with original cost/failure ledgers |
| global-fence sensitivity | Linear exact gap certificate, correlated destination uncertainty, independent enumeration and counterexamples |
| host schedule replay | Thirteen saved native traces, independent static matching certificates, global and tile-local installation |

Every archive contains its own README, proof/scope statements and frozen expected records. Archived measurements are separate from fresh replay timings. Saved-trace replay checks recorded observations. Rebuilding and executing the hardware simulator requires the upstream project and pinned environment, which these portable packages do not bundle. Source-level program equivalence, general liveness and a complete public-mapper ranking remain open.

## Platform and public inputs

The native platform is [VectorCGRA](https://github.com/tancheng/VectorCGRA), with manuscript-specific source and patch pins recorded in the research evidence. The placement bridge starts from [SAT-MapIt](https://github.com/CristianTirelli/SAT-MapIt/tree/82c30993b087fb1b836f7e5d485bcc6db04b6fe7). External project licenses apply to their code. The portable suite above has no network dependency or external benchmark dependency.

The ISCAS85 study uses the eleven allowlisted ISCAS85 files from the [mockturtle benchmark directory](https://github.com/lsils/mockturtle/tree/420f0271ab9f63a1644bf465ab47c970c173bd7b/experiments/benchmarks), followed by the frozen ABC preprocessing sequence recorded in `benchmark_manifest.json`. The project distinguishes ISCAS85 development graphs from the separate frozen EPFL evaluation suite. The frozen EPFL suite has zero development reads. The portable application inputs and configuration streams are included in the archives.

## Evidence boundaries

The original ISCAS85 matrix retains all 44 cells, including timeouts, RSS crashes and not-expressible cases. Router/encoding successors have separate budgets, records and failure denominators. Intermediate lowerer records are distinct from hardware configuration packets. All native results in the paper use the explicit physical true-return and store-visibility contract. The archives retain original rejections and corrected saved-checker dispositions where provided.

No authentication material, portal receipt, author account state or unrelated project content is included.

## Optional deterministic-router study

`optional_d_mapper/` includes mapper source, all eleven adapted graphs, the fixed hardware/protocol, all original and successor cell receipts, three accepted candidates and seventeen checker-rejected candidates. Run `python3 -B optional_d_mapper/verify.py` to validate hashes and replay all twenty candidate checks without mapping. Its README provides optional fresh mapping commands and explains that archived resource supervision belongs to the external frozen controller. The default six-package suite above remains the archived application/theory verification entry.
